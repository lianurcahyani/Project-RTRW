<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/iuran/update/{{$iuran->id}}" method="post">
    <table align="center">
        @csrf
        @method('PUT')
        <tr>
            <td>Tanggal Update Iuran</td>
            <td>
                <input type="text" name="tanggal_update_iuran" value="{{$iuran->tanggal_update_iuran}}">
            </td>
        </tr>
        <tr>
            <td>Nominal Iuran</td>
            <td>
                <input type="text" name="nominal_iuran" value="{{$iuran->nominal_iuran}}">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html>

@extends('layouts.app')
@section('content')
<div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Data RW</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form" action="/warga/update/{{$warga->id}}" method="post">
                                @csrf
                                @method('PUT')
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">Tanggal Update Iuran</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="Masukkan Tanggal Update Iuran" name="tanggal_update_iuran" value="{{$warga->tanggal_update_iuran}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Nominal Iuran</label>
                                            <input type="number" id="last-name-column" class="form-control" placeholder="Masukkan Nominal Iuran" name="nominal_iuran" value="{{$warga->nominal-iuran}}">
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
@endsection