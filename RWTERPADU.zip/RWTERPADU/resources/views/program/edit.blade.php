<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/program/update/{{$program->id}}" method="post">
    <table align="center">
        @csrf
        @method('PUT')
        <tr>
            <td>Kas</td>
            <td>
                <input type="text" name="kas" value="{{$program->kas}}">
            </td>
        </tr>
        <tr>
            <td>Kebersihan</td>
            <td>
                <input type="text" name="kebersihan" value="{{$program->kebersihan}}">
            </td>
        </tr>
        <tr>
            <td>Keamanan</td>
            <td>
                <input type="text" name="keamanan" value="{{$program->keamanan}}">
            </td>
        </tr>
        <tr>
            <td>kematian</td>
            <td>
                <input type="text" name="kematian" value="{{$program->kematian}}">
            </td>
        </tr>
        <tr>
            <td>Kegiatan</td>
            <td>
                <input type="text" name="kegiatan" value="{{$program->kegiatan}}">
            </td>
        </tr>
        <tr>
            <td>Bencana</td>
            <td>
                <input type="text" name="bencana" value="{{$program->bencana}}">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html>

@extends('layouts.app')
@section('content')
<div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Data Program</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form" action="/warga/update/{{$warga->id}}" method="post">
                                @csrf
                                @method('PUT')
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">Kas</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="Masukkan Kas" name="kas" value="{{$warga->kas}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Kebersihan</label>
                                            <input type="number" id="last-name-column" class="form-control" placeholder="Masukkan Kebersihan" name="kebersihan" value="{{$warga->kebersihan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Keamanan</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="Masukkan Keamanan" name="keamanan" value="{{$warga->keamanan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">Kematian</label>
                                            <input type="email" id="country-floating" class="form-control" name="kematian" placeholder="Masukkan Kematian" value="{{$warga->kematian}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Kegiatan</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="Masukkan Kegiatan" name="kegiatan" value="{{$warga->kegiatan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">Bencana</label>
                                            <input type="email" id="country-floating" class="form-control" name="bencana" placeholder="Masukkan Bencana" value="{{$warga->bencana}}">
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
@endsection