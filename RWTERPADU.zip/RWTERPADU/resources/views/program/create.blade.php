<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/program/store" method="post">
    @csrf
    <tr>
        <td>Kas</td>
        <input type="text" name="kas">
    </tr>
    <tr>
        <td>Kebersihan</td>
        <input type="text" name="kebersihan">
    </tr>
    <tr>
        <td>Keamanan</td>
        <input type="text" name="keamanan">
    </tr>
    <tr>
        <td>Kematian</td>
        <input type="text" name="kematian">
    </tr>
    <tr>
        <td>Kegiatan</td>
        <input type="text" name="kegiatan">
    </tr>
    <tr>
        <td>Bencana</td>
        <input type="text" name="bencana">
    </tr>
    <tr>
        <button type="submit">Simpan</button>
    </tr>
</form>
</body>
</html>