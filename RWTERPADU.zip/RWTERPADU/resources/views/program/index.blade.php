@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-hover">
        <thead>
            <th>NO</th>
            <th>Kas</th>
            <th>Kebersihan</th>
            <th>Keamanan</th>
            <th>Kematian</th>
            <th>Kegiatan</th>
            <th>Bencana</th>
            <th>Action</th>
        </thead>
       @foreach ($program as $isi=> $a)
        <tbody>
            <tr>
                <td>{{$isi+1}}</td>
                <td>{{$a->kas}}</td>
                <td>{{$a->kebersihan}}</td>
                <td>{{$a->keamanan}}</td>
                <td>{{$a->kematian}}</td>
                <td>{{$a->kegiatan}}</td>
                <td>{{$a->bencana}}</td>
                <td><a href="/program/edit/{{$a->id}}">Edit</a>
                    <a href="/program/destroy/{{$a->id}}">Hapus</a>
                </td>
            </tr>
           
        @endforeach
    </table>
    <a href="/program/create">Tambah</a>
</body>
</html>
@endsection