@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-hover">
        <thead>
            <th>NO</th>
            <th>Nama RT</th>
            <th>Masa Jabatan</th>
            <th>No Telpon</th>
            <th>Email</th>
            <th>Action</th>
        </thead>
       @foreach ($rt as $isi=> $a)
        <tbody>
            <tr>
                <td>{{$isi+1}}</td>
                <td>{{$a->nama_rt}}</td>
                <td>{{$a->masa_jabatan}}</td>
                <td>{{$a->no_telp}}</td>
                <td>{{$a->email}}</td>
                <td><a href="/rt/edit/{{$a->id}}">Edit</a>
                    <a href="/rt/destroy/{{$a->id}}">Hapus</a>
                    <a href="/rt/show/{{$a->id}}">Show</a></td>
            </tr>
           
        @endforeach
    </table>
    <a href="/rt/create">Tambah</a>
</body>
</html>
@endsection