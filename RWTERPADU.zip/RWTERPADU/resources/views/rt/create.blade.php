<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/rt/store" method="post">
    @csrf
    <tr>
        <td>Nama RT</td>
        <input type="text" name="nama_rt">
    </tr>
    <tr>
        <td>Masa Jabatan</td>
        <input type="text" name="masa_jabatan">
    </tr>
    <tr>
        <td>No Telp</td>
        <input type="text" name="no_telp">
    </tr>
    <tr>
        <td>Email</td>
        <input type="text" name="email">
    </tr>
    <tr>
        <button type="submit">Simpan</button>
    </tr>
</form>
</body>
</html>

@extends('layouts.app')
@section('content')
<div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Tambah Data RT</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form" action="/warga/store" method="post">
                                @csrf
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Nama RT</label>
                                            <input type="text" id="last-name-column" class="form-control" placeholder="Masukkan Nama RT" name="nama">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Masa Jabatan</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="Masukkan Masa Jabatan" name="masa_jabatan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">No Telp</label>
                                            <input type="text" id="country-floating" class="form-control" name="no_telp" placeholder="Masukkan No Telp">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">No Rumah</label>
                                            <input type="number" id="email-id-column" class="form-control" name="no_rumah" placeholder="Masukkan No Rumah">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Email</label>
                                            <input type="email" id="email-id-column" class="form-control" name="email" placeholder="Masukkan Email">
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
@endsection