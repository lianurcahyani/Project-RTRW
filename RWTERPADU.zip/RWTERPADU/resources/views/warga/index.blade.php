@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table class="table table-hover">
        <thead>
            <th>NO</th>
            <th>NIK</th>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Tempat Lahir</th>
            <th>Tanggal Lahir</th>
            <th>Pekerjaan</th>
            <th>Action</th>
        </thead>
       @foreach ($warga as $isi=> $a)
        <tbody>
            <tr>
                <td>{{$isi+1}}</td>
                <td>{{$a->nik}}</td>
                <td>{{$a->nama}}</td>
                <td>{{$a->jenkel}}</td>
                <td>{{$a->tempat_lahir}}</td>
                <td>{{$a->tanggal_lahir}}</td>
                <td>{{$a->pekerjaan}}</td>
                <td><a href="/warga/edit/{{$a->id}}">Edit</a>
                    <a href="/warga/destroy/{{$a->id}}">Hapus</a>
                    <a href="/warga/show/{{$a->id}}">Show</a></td>
            </tr>
        @endforeach
    </table>
    <a href="/warga/create">Tambah</a>
</body>
</html>
@endsection