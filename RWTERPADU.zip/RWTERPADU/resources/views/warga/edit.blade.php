
@extends('layouts.app')
@section('content')
<div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Data Warga</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form" action="/warga/update/{{$warga->id}}" method="post">
                                @csrf
                                @method('PUT')
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">NIK</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="Masukkan NIK" name="nik" value="{{$warga->nik}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Nama</label>
                                            <input type="text" id="last-name-column" class="form-control" placeholder="Masukkan Nama" name="nama" value="{{$warga->nama}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Jenis Kelamin</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="Masukkan Jenis Kelamin" name="jenkel" value="{{$warga->jenkel}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">Tempat Lahir</label>
                                            <input type="text" id="country-floating" class="form-control" name="tempat_lahir" placeholder="Masukkan Tempat lahir" value="{{$warga->tempat_lahir}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="company-column">Tanggal Lahir</label>
                                            <input type="date" id="company-column" class="form-control" name="tanggal_lahir" placeholder="Masukkan Tanggal Lahir" value="{{$warga->tanggal_lahir}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Pekerjaan</label>
                                            <input type="text" id="email-id-column" class="form-control" name="pekerjaan" placeholder="Masukkan Pekerjaan" value="{{$warga->pekerjaan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Penghasilan</label>
                                            <input type="number" id="email-id-column" class="form-control" name="penghasilan" placeholder="Masukkan Penghasilan" value="{{$warga->penghasilan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Kota</label>
                                            <input type="text" id="email-id-column" class="form-control" name="kota" placeholder="Masukkan Kota" value="{{$warga->kota}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Kecamatan</label>
                                            <input type="text" id="email-id-column" class="form-control" name="kecamatan" placeholder="Masukkan Kecamatan" value="{{$warga->kecamatan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Kelurahan</label>
                                            <input type="text" id="email-id-column" class="form-control" name="kelurahan" placeholder="Masukkan Kelurahan" value="{{$warga->kelurahan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Alamat</label>
                                            <input type="text" id="email-id-column" class="form-control" name="alamat" placeholder="Masukkan Alamat" value="{{$warga->alamat}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">No Rumah</label>
                                            <input type="number" id="email-id-column" class="form-control" name="no_rumah" placeholder="Masukkan No Rumah" value="{{$warga->no_rumah}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Email</label>
                                            <input type="email" id="email-id-column" class="form-control" name="email" placeholder="Masukkan Email" value="{{$warga->email}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Passwoard</label>
                                            <input type="passwoard" id="email-id-column" class="form-control" name="passwoard" placeholder="Masukkan Passwoard" value="{{$warga->passwoard}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Qr Code</label>
                                            <input type="number" id="email-id-column" class="form-control" name="qrcode" placeholder="Masukkan Qr Code" value="{{$warga->qrcode}}">
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
@endsection