@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-hover">
        <tr>
            <td>Penghasilan</td>
            <td> : {{$warga->penghasilan}}</td>
        </tr>
        <tr>
            <td>Kota</td>
            <td> : {{$warga->kota}}</td>
        </tr>
        <tr>
            <td>Kecamatan</td>
            <td> : {{$warga->kecamatan}}</td>
        </tr>
        <tr>
            <td>Kelurahan</td>
            <td> : {{$warga->kelurahan}}</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td> : {{$warga->alamat}}</td>
        </tr>
        <tr>
            <td>No Rumah</td>
            <td> : {{$warga->no_rumah}}</td>
        </tr>
        <tr>
            <td>Email</td>
            <td> : {{$warga->email}}</td>
        </tr>
        <tr>
            <td>Passwoard</td>
            <td> : {{$warga->passwoard}}</td>
        </tr>
        <tr>
            <td>Qr Code</td>
            <td> : {{$warga->qrcode}}</td>
        </tr>
    </table>
    <a href="/warga">Simpan</a>
</body>
</html>
@endsection