<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/kelurahan/update/{{$kelurahan->id}}" method="post">
    <table align="center">
        @csrf
        @method('PUT')
        <tr>
            <td>Nama Kelurahan</td>
            <td>
                <input type="text" name="nama_kelurahan" value="{{$kelurahan->nama_kelurahan}}">
            </td>
        </tr>
        <tr>
            <td>Nama Lurah</td>
            <td>
                <input type="text" name="nama_lurah" value="{{$kelurahan->nama_lurah}}">
            </td>
        </tr>
        <tr>
            <td>Masa Jabatan</td>
            <td>
                <input type="text" name="masa_jabatan" value="{{$kelurahan->masa_jabatan}}">
            </td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>
                <input type="text" name="no_telp" value="{{$kelurahan->no_telp}}">
            </td>
        </tr>
        <tr>
            <td>Email</td>
            <td>
                <input type="email" name="email" value="{{$kelurahan->email}}">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html>

@extends('layouts.app')
@section('content')
<div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Data Kelurahan</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form" action="/warga/update/{{$warga->id}}" method="post">
                                @csrf
                                @method('PUT')
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">Nama Kelurahan</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="Masukkan Nama Kelurahan" name="nama_kelurahan" value="{{$warga->nama_kelurahan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Nama Lurah</label>
                                            <input type="number" id="last-name-column" class="form-control" placeholder="Masukkan Nama Lurah" name="nama_lurah" value="{{$warga->nama_lurah}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Masa Jabatan</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="Masukkan Masa Jabatan" name="masa_jabatan" value="{{$warga->masa_jabatan}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">No Telp</label>
                                            <input type="email" id="country-floating" class="form-control" name="no_telp" placeholder="Masukkan No Telp" value="{{$warga->no_telp}}">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Email</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="Masukkan Email" name="email" value="{{$warga->email}}">
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
@endsection