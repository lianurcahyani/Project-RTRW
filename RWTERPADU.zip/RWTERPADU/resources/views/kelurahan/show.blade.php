<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table>
        <tr>
            <td>Nama Kelurahan</td>
            <td> : {{$kelurahan->nama_kelurahan}}</td>
        </tr>
        <tr>
            <td>Nama Lurah</td>
            <td> : {{$kelurahan->nama_lurah}}</td>
        </tr>
        <tr>
            <td>Masa Jabatan</td>
            <td> : {{$kelurahan->masa_jabatan}}</td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td> : {{$kelurahan->no_telp}}</td>
        </tr>
        <tr>
            <td>Email</td>
            <td> : {{$kelurahan->email}}</td>
        </tr>
    </table>
    <a href="/kelurahan">Simpan</a>
</body>
</html>