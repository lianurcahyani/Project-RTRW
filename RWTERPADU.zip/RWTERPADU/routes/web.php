<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layouts.app');
});

//RT
Route::get('/rt','RTController@index');
Route::get('/rt/create', 'RTController@create');
Route::post('/rt/store', 'RTController@store');
Route::get('/rt/edit/{id}', 'RTController@edit');
Route::put('/rt/update/{id}', 'RTController@update');
Route::get('/rt/destroy/{id}', 'RTController@destroy');
Route::get('rt/show/{id}', 'RTController@show');

//RW
Route::get('/rw', 'RWController@index');
Route::get('/rw/create', 'RWController@create');
Route::post('/rw/store', 'RWController@store');
Route::get('/rw/edit/{id}', 'RWController@edit');
Route::put('/rw/update/{id}', 'RWController@update');
Route::get('/rw/destroy/{id}', 'RWController@destroy');
Route::get('rw/show/{id}', 'RWController@show');

//Kelurahan
Route::get('/kelurahan', 'KelurahanController@index');
Route::get('/kelurahan/create', 'KelurahanController@create');
Route::post('/kelurahan/store', 'KelurahanController@store');
Route::get('/kelurahan/edit/{id}', 'KelurahanController@edit');
Route::put('/kelurahan/update/{id}', 'KelurahanController@update');
Route::get('/kelurahan/destroy/{id}', 'KelurahanController@destroy');
Route::get('/kelurahan/show/{id}', 'KelurahanController@show');

//kecamatan
Route::get('/kecamatan', 'KecamatanController@index');
Route::get('/kecamatan/create', 'KecamatanController@create');
Route::post('/kecamatan/store', 'KecamatanController@store');
Route::get('/kecamatan/edit/{id}', 'KecamatanController@edit');
Route::put('/kecamatan/update/{id}', 'KecamatanController@update');
Route::get('/kecamatan/destroy/{id}', 'KecamatanController@destroy');

//petugas
Route::get('/petugas', 'PetugasController@index');
Route::get('/petugas/create', 'PetugasController@create');
Route::post('/petugas/store', 'PetugasController@store');
Route::get('/petugas/edit/{id}', 'PetugasController@edit');
Route::put('/petugas/update/{id}', 'PetugasController@update');
Route::get('/petugas/destroy/{id}', 'PetugasController@destroy');

//iuran
Route::get('/iuran', 'IuranController@index');
Route::get('/iuran/create', 'IuranController@create');
Route::post('/iuran/store', 'IuranController@store');
Route::get('/iuran/edit/{id}', 'IuranController@edit');
Route::put('/iuran/update/{id}', 'IuranController@update');
Route::get('/iuran/destroy/{id}', 'IuranController@destroy');

//warga
Route::get('/warga', 'WargaController@index');
Route::get('/warga/create', 'WargaController@create');
Route::post('/warga/store', 'WargaController@store');
Route::get('/warga/edit/{id}', 'WargaController@edit');
Route::put('/warga/update/{id}', 'WargaController@update');
Route::get('/warga/destroy/{id}', 'WargaController@destroy');
Route::get('warga/show/{id}', 'WargaController@show');

//program
Route::get('/program', 'Programcontroller@index');
Route::get('/program/create', 'Programcontroller@create');
Route::post('/program/store', 'Programcontroller@store');
Route::get('/program/edit/{id}', 'Programcontroller@edit');
Route::put('/program/update/{id}', 'Programcontroller@update');
Route::get('/program/destroy/{id}', 'Programcontroller@destroy');