<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kelurahan extends Model
{
    protected $table ='kelurahans';
    protected $fillable =['nama_kelurahan', 'nama_lurah', 'masa_jabatan', 'no_telp', 'email'];
    protected $primaryKey ='id';
}
