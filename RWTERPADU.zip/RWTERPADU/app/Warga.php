<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Warga extends Model
{
    protected $table ='wargas';
    protected $fillable =['nik', 'nama', 'jenkel', 'tempat_lahir', 'tanggal_lahir', 'pekerjaan', 'penghasilan', 'kota', 'kecamatan', 
                            'kelurahan', 'alamat', 'no_rumah', 'email', 'passwoard', 'qrcode'];
    protected $primaryKey ='id';
}
