<?php

namespace App\Http\Controllers;

use App\Warga;
use Illuminate\Http\Request;

class WargaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $warga = Warga::all();
        return view('warga.index', compact('warga'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $warga = Warga::all();
        return view('warga.create', compact('warga'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $value = [
            'nik'=>$request ->nik,
            'nama'=>$request ->nama,
            'jenkel'=>$request ->jenkel,
            'tempat_lahir'=>$request ->tempat_lahir,
            'tanggal_lahir'=>$request ->tanggal_lahir,
            'pekerjaan'=>$request ->pekerjaan,
            'penghasilan'=>$request ->penghasilan,
            'kota'=>$request ->kota,
            'kecamatan'=>$request ->kecamatan,
            'kelurahan'=>$request ->kelurahan,
            'alamat'=>$request ->alamat,
            'no_rumah'=>$request ->no_rumah,
            'email'=>$request ->email,
            'passwoard'=>$request ->passwoard,
            'qrcode'=>$request ->qrcode
        ];
        warga::create($value);
        return redirect('/warga');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $warga = warga::find($id);
        return view('warga.show', compact('warga'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $warga = warga::find($id);
        return view('warga.edit', compact('warga'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $modal = warga::find($id);
        $value = [
            'nik'=>$request ->nik,
            'nama'=>$request ->nama,
            'jenkel'=>$request ->jenkel,
            'tempat_lahir'=>$request ->tempat_lahir,
            'tanggal_lahir'=>$request ->tanggal_lahir,
            'pekerjaan'=>$request ->pekerjaan,
            'penghasilan'=>$request ->penghasilan,
            'kota'=>$request ->kota,
            'kecamatan'=>$request ->kecamatan,
            'kelurahan'=>$request ->kelurahan,
            'alamat'=>$request ->alamat,
            'no_rumah'=>$request ->no_rumah,
            'email'=>$request ->email,
            'passwoard'=>$request ->passwoard,
            'qrcode'=>$request ->qrcode
        ];
        $modal->update($value);
        return redirect('/warga');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $warga = warga::destroy($id);
        return redirect('/warga');
    }
}
