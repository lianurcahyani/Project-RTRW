<?php

namespace App\Http\Controllers;

use App\RT;
use Illuminate\Http\Request;

class RTController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rt = RT::all();
        return view('rt.index', compact('rt'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $rt = RT::all();
        return view('rt.create', compact('rt'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $value = [
            'nama_rt'=>$request ->nama_rt,
            'masa_jabatan'=>$request ->masa_jabatan,
            'no_telp'=>$request ->no_telp,
            'email'=>$request ->email
        ];
        rt::create($value);
        return redirect('/rt');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\RT  $rT
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $rt = rt::find($id);
        return view('rt.show', compact('rt'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\RT  $rT
     * @return \Illuminate\Http\Response
     */
    public function edit ($id)
    {
        $rt = rt::find($id);
        return view('rt.edit', compact('rt'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\RT  $rT
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $modal = rt::find($id);
        $value = [
            'nama_rt'=>$request ->nama_rt,
            'masa_jabatan'=>$request ->masa_jabatan,
            'no_telp'=>$request ->no_telp,
            'email'=>$request ->email
        ];
        $modal->update($value);
        return redirect('/rt');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\RT  $rT
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $rt = rt::destroy($id);
        return redirect('/rt');
    }
}
