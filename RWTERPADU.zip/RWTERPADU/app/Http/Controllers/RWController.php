<?php

namespace App\Http\Controllers;

use App\RW;
use Illuminate\Http\Request;

class RWController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rw = RW::all();
        return view('rw.index', compact('rw'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $rw = RW::all();
        return view('rw.create', compact('rw'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $value = [
            'nama_rw'=>$request ->nama_rw,
            'masa_jabatan'=>$request ->masa_jabatan,
            'no_telp'=>$request ->no_telp,
            'email'=>$request ->email
        ];
        RW::create($value);
        return redirect('/rw');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $rw = rw::find($id);
        return view('rw.show', compact('rw'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $rw = rw::find($id);
        return view('rw.edit', compact('rw'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $modal = rw::find($id);
        $value = [
            'nama_rw'=>$request ->nama_rw,
            'masa_jabatan'=>$request ->masa_jabatan,
            'no_telp'=>$request ->no_telp,
            'email'=>$request ->email
        ];
        $modal->update($value);
        return redirect('/rw');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $rw = rw::destroy($id);
        return redirect('/rw');
    }
}
