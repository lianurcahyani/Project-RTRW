<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Iuran extends Model
{
    protected $table='iurans';
    protected $fillable =['tanggal_update_iuran', 'nominal_iuran'];
    protected $primaryKey ='id';
}
