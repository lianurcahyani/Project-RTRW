<?php $__env->startSection('content'); ?>
<div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Tambah Data Warga</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form class="form" action="/warga/store" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">NIK</label>
                                            <input type="text" id="first-name-column" class="form-control" placeholder="Masukkan NIK" name="nik">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="last-name-column">Nama</label>
                                            <input type="text" id="last-name-column" class="form-control" placeholder="Masukkan Nama" name="nama">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="city-column">Jenis Kelamin</label>
                                            <input type="text" id="city-column" class="form-control" placeholder="Masukkan Jenis Kelamin" name="jenkel">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="country-floating">Tempat Lahir</label>
                                            <input type="text" id="country-floating" class="form-control" name="tempat_lahir" placeholder="Masukkan Tempat lahir">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="company-column">Tanggal Lahir</label>
                                            <input type="date" id="company-column" class="form-control" name="tanggal_lahir" placeholder="Masukkan Tanggal Lahir">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Pekerjaan</label>
                                            <input type="text" id="email-id-column" class="form-control" name="pekerjaan" placeholder="Masukkan Pekerjaan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Penghasilan</label>
                                            <input type="number" id="email-id-column" class="form-control" name="penghasilan" placeholder="Masukkan Penghasilan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Kota</label>
                                            <input type="text" id="email-id-column" class="form-control" name="kota" placeholder="Masukkan Kota">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Kecamatan</label>
                                            <input type="text" id="email-id-column" class="form-control" name="kecamatan" placeholder="Masukkan Kecamatan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Kelurahan</label>
                                            <input type="text" id="email-id-column" class="form-control" name="kelurahan" placeholder="Masukkan Kelurahan">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Alamat</label>
                                            <input type="text" id="email-id-column" class="form-control" name="alamat" placeholder="Masukkan Alamat">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">No Rumah</label>
                                            <input type="number" id="email-id-column" class="form-control" name="no_rumah" placeholder="Masukkan No Rumah">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Email</label>
                                            <input type="email" id="email-id-column" class="form-control" name="email" placeholder="Masukkan Email">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Passwoard</label>
                                            <input type="passwoard" id="email-id-column" class="form-control" name="passwoard" placeholder="Masukkan Passwoard">
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email-id-column">Qr Code</label>
                                            <input type="number" id="email-id-column" class="form-control" name="qrcode" placeholder="Masukkan Qr Code">
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-12">
                                        <div class="form-check">
                                            <div class="checkbox">
                                                <input type="checkbox" id="checkbox5" class="form-check-input" checked="">
                                                <label for="checkbox5">Remember Me</label>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div class="col-12 d-flex justify-content-end">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/warga/create.blade.php ENDPATH**/ ?>