<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/program/update/<?php echo e($program->id); ?>" method="post">
    <table align="center">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <tr>
            <td>Kas</td>
            <td>
                <input type="text" name="kas" value="<?php echo e($program->kas); ?>">
            </td>
        </tr>
        <tr>
            <td>Kebersihan</td>
            <td>
                <input type="text" name="kebersihan" value="<?php echo e($program->kebersihan); ?>">
            </td>
        </tr>
        <tr>
            <td>Keamanan</td>
            <td>
                <input type="text" name="keamanan" value="<?php echo e($program->keamanan); ?>">
            </td>
        </tr>
        <tr>
            <td>kematian</td>
            <td>
                <input type="text" name="kematian" value="<?php echo e($program->kematian); ?>">
            </td>
        </tr>
        <tr>
            <td>Kegiatan</td>
            <td>
                <input type="text" name="kegiatan" value="<?php echo e($program->kegiatan); ?>">
            </td>
        </tr>
        <tr>
            <td>Bencana</td>
            <td>
                <input type="text" name="bencana" value="<?php echo e($program->bencana); ?>">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/program/edit.blade.php ENDPATH**/ ?>