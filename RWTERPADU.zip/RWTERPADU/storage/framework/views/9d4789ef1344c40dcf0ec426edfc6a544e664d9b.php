<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/petugas/update/<?php echo e($petugas->id); ?>" method="post">
    <table align="center">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <tr>
            <td>Nama Petugas</td>
            <td>
                <input type="text" name="nama_petugas" value="<?php echo e($petugas->nama_petugas); ?>">
            </td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>
                <input type="text" name="no_telp" value="<?php echo e($petugas->no_telp); ?>">
            </td>
        </tr>
        <tr>
            <td>Email</td>
            <td>
                <input type="text" name="email" value="<?php echo e($petugas->email); ?>">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/petugas/edit.blade.php ENDPATH**/ ?>