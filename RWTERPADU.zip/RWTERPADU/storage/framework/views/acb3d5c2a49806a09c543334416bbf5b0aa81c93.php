<ul class="menu">
            
            
            <li class='sidebar-title'>Main Menu</li>
        
        
        
            <li class="sidebar-item active ">
                <a href="index.html" class='sidebar-link'>
                    <i data-feather="home" width="20"></i> 
                    <span>Dashboard</span>
                </a>
                
            </li>

        
        
        
            <li class="sidebar-item  has-sub">
                <a href="#" class='sidebar-link'>
                    <i data-feather="triangle" width="20"></i> 
                    <span>Data - Data</span>
                </a>
                
                <ul class="submenu ">
                    
                    <li>
                        <a href="/warga">Warga</a>
                    </li>
                    
                    <li>
                        <a href="/petugas">Petugas</a>
                    </li>
                    
                    <li>
                        <a href="/rt">RT</a>
                    </li>
                    
                    <li>
                        <a href="/rw">RW</a>
                    </li>
                    
                    <li>
                        <a href="/kelurahan">Kelurahan</a>
                    </li>
                    
                    <li>
                        <a href="/kecamatan">Kecamatan</a>
                    </li>
                    
                    <li>
                        <a href="/iuran">Iuran</a>
                    </li>
                    
                    <li>
                        <a href="/program">Program</a>
                    </li>
                    
                    
                </ul>
                
            </li>

        
      
        
     
    </ul><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>