<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-hover">
        <tr>
            <td>Penghasilan</td>
            <td> : <?php echo e($warga->penghasilan); ?></td>
        </tr>
        <tr>
            <td>Kota</td>
            <td> : <?php echo e($warga->kota); ?></td>
        </tr>
        <tr>
            <td>Kecamatan</td>
            <td> : <?php echo e($warga->kecamatan); ?></td>
        </tr>
        <tr>
            <td>Kelurahan</td>
            <td> : <?php echo e($warga->kelurahan); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td> : <?php echo e($warga->alamat); ?></td>
        </tr>
        <tr>
            <td>No Rumah</td>
            <td> : <?php echo e($warga->no_rumah); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td> : <?php echo e($warga->email); ?></td>
        </tr>
        <tr>
            <td>Passwoard</td>
            <td> : <?php echo e($warga->passwoard); ?></td>
        </tr>
        <tr>
            <td>Qr Code</td>
            <td> : <?php echo e($warga->qrcode); ?></td>
        </tr>
    </table>
    <a href="/warga">Simpan</a>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/warga/show.blade.php ENDPATH**/ ?>