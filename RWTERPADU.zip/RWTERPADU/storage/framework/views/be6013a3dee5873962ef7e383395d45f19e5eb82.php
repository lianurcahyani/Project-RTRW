<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-hover">
        <thead>
            <th>NO</th>
            <th>Kas</th>
            <th>Kebersihan</th>
            <th>Keamanan</th>
            <th>Kematian</th>
            <th>Kegiatan</th>
            <th>Bencana</th>
            <th>Action</th>
        </thead>
       <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi=> $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($isi+1); ?></td>
                <td><?php echo e($a->kas); ?></td>
                <td><?php echo e($a->kebersihan); ?></td>
                <td><?php echo e($a->keamanan); ?></td>
                <td><?php echo e($a->kematian); ?></td>
                <td><?php echo e($a->kegiatan); ?></td>
                <td><?php echo e($a->bencana); ?></td>
                <td><a href="/program/edit/<?php echo e($a->id); ?>">Edit</a>
                    <a href="/program/destroy/<?php echo e($a->id); ?>">Hapus</a>
                </td>
            </tr>
           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/program/create">Tambah</a>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/program/index.blade.php ENDPATH**/ ?>